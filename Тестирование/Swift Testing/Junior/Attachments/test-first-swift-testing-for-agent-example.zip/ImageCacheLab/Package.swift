// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "ImageCacheLab",
    platforms: [.macOS(.v15)],
    products: [.library(name: "ImageCacheLab", targets: ["ImageCacheLab"])],
    targets: [
        .target(name: "ImageCacheLab"),
        .testTarget(name: "ImageCacheLabTests", dependencies: ["ImageCacheLab"])
    ]
)
