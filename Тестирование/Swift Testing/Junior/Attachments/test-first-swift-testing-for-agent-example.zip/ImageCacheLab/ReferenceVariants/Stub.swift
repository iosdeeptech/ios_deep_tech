import Foundation

public struct ImageCache {
    public init(capacity: Int) {}
    public var count: Int { 0 }
    public mutating func insert(_ data: Data, forKey key: String) {}
    public mutating func image(forKey key: String) -> Data? { nil }
    public mutating func remove(forKey key: String) {}
}
