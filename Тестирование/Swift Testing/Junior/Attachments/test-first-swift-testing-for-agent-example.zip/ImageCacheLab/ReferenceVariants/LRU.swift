import Foundation

public struct ImageCache {
    private let capacity: Int
    private var images: [String: Data] = [:]
    private var order: [String] = []

    public init(capacity: Int) {
        precondition(capacity >= 0)
        self.capacity = capacity
    }

    public var count: Int { images.count }

    public mutating func insert(_ data: Data, forKey key: String) {
        guard capacity > 0 else { return }
        images[key] = data
        markAsUsed(key)

        if order.count > capacity {
            images.removeValue(forKey: order.removeFirst())
        }
    }

    public mutating func image(forKey key: String) -> Data? {
        guard let data = images[key] else { return nil }
        markAsUsed(key)
        return data
    }

    public mutating func remove(forKey key: String) {
        images.removeValue(forKey: key)
        order.removeAll { $0 == key }
    }

    private mutating func markAsUsed(_ key: String) {
        order.removeAll { $0 == key }
        order.append(key)
    }
}
