import Foundation

public struct ImageCache {
    private var images: [String: Data] = [:]

    public init(capacity: Int) {}
    public var count: Int { images.count }
    public mutating func insert(_ data: Data, forKey key: String) {
        images[key] = data
    }
    public mutating func image(forKey key: String) -> Data? {
        images[key]
    }
    public mutating func remove(forKey key: String) {
        images.removeValue(forKey: key)
    }
}
