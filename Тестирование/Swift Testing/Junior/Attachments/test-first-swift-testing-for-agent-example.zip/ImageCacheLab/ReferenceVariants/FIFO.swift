import Foundation

public struct ImageCache {
    private let capacity: Int
    private var images: [String: Data] = [:]
    private var order: [String] = []

    public init(capacity: Int) {
        precondition(capacity >= 0)
        self.capacity = capacity
    }

    public var count: Int { images.count }

    public mutating func insert(_ data: Data, forKey key: String) {
        guard capacity > 0 else { return }
        if images[key] == nil { order.append(key) }
        images[key] = data

        if order.count > capacity {
            images.removeValue(forKey: order.removeFirst())
        }
    }

    public mutating func image(forKey key: String) -> Data? {
        images[key]
    }

    public mutating func remove(forKey key: String) {
        images.removeValue(forKey: key)
        order.removeAll { $0 == key }
    }
}
