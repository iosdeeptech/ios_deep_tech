# ImageCacheLab

Учебный пример для статьи iOS Deep Tech «Тест до кода. Swift Testing как постановка задачи». Проверен на Apple Swift 6.3.1, Xcode 26.4.1. Зависимостей из сети нет.

В `Sources` находится правильная реализация LRU. Полный исходный контракт описан в `CONTRACT.md`. Восемь базовых тестов находятся в `VisibleTests.swift`, пятнадцать дополнительных сценариев того же контракта в `HeldOutTests.swift`.

```sh
swift test
swift test --filter VisibleTests
swift test --filter HeldOutTests
```

Всего runner показывает 23 теста. Один из восьми базовых тестов параметризован тремя значениями вместимости, поэтому фактически проверяются 25 случаев.

## Воспроизведение примера

Неправильная FIFO-реализация написана специально для учебного сравнения. Она не получена из сессии другого ассистента. В обоих наборах проверяются заранее описанные требования. Второй набор запускается позже, но не меняет контракт.

```sh
cp ReferenceVariants/Stub.swift Sources/ImageCacheLab/ImageCache.swift
swift test --filter returnsInsertedData

cp ReferenceVariants/Dictionary.swift Sources/ImageCacheLab/ImageCache.swift
swift test --filter returnsInsertedData

cp ReferenceVariants/FIFO.swift Sources/ImageCacheLab/ImageCache.swift
swift test --filter VisibleTests
swift test --filter HeldOutTests

cp ReferenceVariants/LRU.swift Sources/ImageCacheLab/ImageCache.swift
swift test
```

Ожидаемые результаты: заглушка падает, FIFO проходит 8 базовых тестов, но падает в 4 из 15 дополнительных. LRU проходит все 23 теста. Количество `issues` отличается от количества упавших тестов: один тест может сообщить несколько несоответствий.

## Дополнительный пример confirmation

Он выключен при обычной сборке, чтобы не менять набор 8 + 15. Для его отдельного запуска:

```sh
swift test -Xswiftc -DCONFIRMATION_EXAMPLE --filter ConfirmationExamples
```

Пример проверяет однократный синхронный вызов completion при чтении из того же кеша. `confirmation` считает вызовы внутри своей async-операции; сам по себе он не ждёт произвольный callback после её завершения. Trait `.tags(.cache)` группирует тесты и не добавляет проверок поведения.

## Ограничения примера

Массив порядка выбран ради читаемости; поиск и удаление ключа в нём линейные. Это не замер производительности и не рекомендация реализации большого промышленного кеша. Каждый тест создаёт собственную переменную кеша, поэтому тесты не разделяют изменяемое состояние.

Если SwiftPM запускается внутри среды, запрещающей вложенный `sandbox-exec`, понадобится `--disable-sandbox` для SwiftPM. В проверенной среде Codex также были перенаправлены module caches в рабочую папку. Обычному локальному запуску это не требуется.
