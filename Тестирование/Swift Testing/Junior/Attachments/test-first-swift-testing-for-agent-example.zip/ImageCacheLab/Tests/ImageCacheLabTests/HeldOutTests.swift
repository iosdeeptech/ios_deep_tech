import Foundation
import Testing
@testable import ImageCacheLab

@Suite("Отложенная проверка исходного контракта", .tags(.cache))
struct HeldOutTests {
    @Test("Чтение обновляет порядок использования")
    func readRefreshesRecency() throws {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([2]), forKey: "b")
        let read1 = cache.image(forKey: "a")
        _ = try #require(read1)
        cache.insert(Data([3]), forKey: "c")
        #expect(cache.image(forKey: "b") == nil)
        #expect(cache.image(forKey: "a") == Data([1]))
    }

    @Test("Перезапись обновляет порядок использования")
    func replacementRefreshesRecency() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([2]), forKey: "b")
        cache.insert(Data([9]), forKey: "a")
        cache.insert(Data([3]), forKey: "c")
        #expect(cache.image(forKey: "b") == nil)
        #expect(cache.image(forKey: "a") == Data([9]))
    }

    @Test("Повторное чтение не размножает ключ в порядке")
    func repeatedReadDoesNotDuplicateEntry() throws {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([2]), forKey: "b")
        for _ in 0..<3 {
            let result = cache.image(forKey: "a")
            _ = try #require(result)
        }
        cache.insert(Data([3]), forKey: "c")
        #expect(cache.count == 2)
        #expect(cache.image(forKey: "b") == nil)
        #expect(cache.image(forKey: "a") == Data([1]))
    }

    @Test("Промах чтения не меняет порядок")
    func missingReadLeavesOrderUnchanged() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([2]), forKey: "b")
        #expect(cache.image(forKey: "missing") == nil)
        cache.insert(Data([3]), forKey: "c")
        #expect(cache.image(forKey: "a") == nil)
        #expect(cache.image(forKey: "b") == Data([2]))
    }

    @Test("Повторная вставка удалённого ключа считается новой")
    func reinsertedKeyIsNewest() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([2]), forKey: "b")
        cache.remove(forKey: "a")
        cache.insert(Data([9]), forKey: "a")
        cache.insert(Data([3]), forKey: "c")
        #expect(cache.image(forKey: "b") == nil)
        #expect(cache.image(forKey: "a") == Data([9]))
    }

    @Test("Удаление старого ключа освобождает место")
    func removingOldestFreesSlot() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([2]), forKey: "b")
        cache.remove(forKey: "a")
        cache.insert(Data([3]), forKey: "c")
        #expect(cache.count == 2)
        #expect(cache.image(forKey: "b") == Data([2]))
        #expect(cache.image(forKey: "c") == Data([3]))
    }

    @Test("Удаление нового ключа не вытесняет старый")
    func removingNewestFreesSlot() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([2]), forKey: "b")
        cache.remove(forKey: "b")
        cache.insert(Data([3]), forKey: "c")
        #expect(cache.count == 2)
        #expect(cache.image(forKey: "a") == Data([1]))
        #expect(cache.image(forKey: "c") == Data([3]))
    }

    @Test("При вместимости один остаётся последний ключ")
    func capacityOneKeepsNewestKey() {
        var cache = ImageCache(capacity: 1)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([2]), forKey: "b")
        #expect(cache.count == 1)
        #expect(cache.image(forKey: "a") == nil)
        #expect(cache.image(forKey: "b") == Data([2]))
    }

    @Test("Нулевой кеш не возвращает вставленные данные")
    func zeroCapacityNeverStoresData() {
        var cache = ImageCache(capacity: 0)
        for key in ["a", "b", "c"] {
            cache.insert(Data([1]), forKey: key)
            #expect(cache.image(forKey: key) == nil)
        }
        #expect(cache.count == 0)
    }

    @Test("Многократная перезапись оставляет одну запись")
    func repeatedWritesKeepOneEntry() {
        var cache = ImageCache(capacity: 2)
        for byte in UInt8(0)..<10 {
            cache.insert(Data([byte]), forKey: "a")
        }
        #expect(cache.count == 1)
        #expect(cache.image(forKey: "a") == Data([9]))
    }

    @Test("Пустая строка допустима как ключ")
    func emptyStringIsValidKey() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "")
        #expect(cache.image(forKey: "") == Data([1]))
    }

    @Test("Одинаковые данные под разными ключами независимы")
    func equalPayloadsDoNotMergeKeys() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([1]), forKey: "b")
        cache.remove(forKey: "a")
        #expect(cache.count == 1)
        #expect(cache.image(forKey: "b") == Data([1]))
    }

    @Test("Изменение исходного Data не меняет сохранённое значение")
    func storesDataValue() {
        var cache = ImageCache(capacity: 2)
        var data = Data([1])
        cache.insert(data, forKey: "a")
        data.append(2)
        #expect(cache.image(forKey: "a") == Data([1]))
    }

    @Test("Копия кеша изменяется независимо")
    func copiedCacheIsIndependent() {
        var original = ImageCache(capacity: 2)
        original.insert(Data([1]), forKey: "a")
        var copy = original
        copy.remove(forKey: "a")
        #expect(original.image(forKey: "a") == Data([1]))
        #expect(copy.image(forKey: "a") == nil)
    }

    @Test("После нескольких вытеснений сохраняет недавно прочитанный ключ")
    func repeatedEvictionPreservesRecentRead() throws {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([2]), forKey: "b")
        let read2 = cache.image(forKey: "a")
        _ = try #require(read2)
        cache.insert(Data([3]), forKey: "c")
        let read3 = cache.image(forKey: "a")
        _ = try #require(read3)
        cache.insert(Data([4]), forKey: "d")
        #expect(cache.count == 2)
        #expect(cache.image(forKey: "a") == Data([1]))
        #expect(cache.image(forKey: "d") == Data([4]))
        #expect(cache.image(forKey: "b") == nil)
        #expect(cache.image(forKey: "c") == nil)
    }
}
