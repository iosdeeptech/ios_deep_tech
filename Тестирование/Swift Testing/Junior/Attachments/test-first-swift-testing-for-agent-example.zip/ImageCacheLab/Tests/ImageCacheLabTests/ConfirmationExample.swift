#if CONFIRMATION_EXAMPLE
import Foundation
import Testing
@testable import ImageCacheLab

private func loadCachedImage(
    from cache: inout ImageCache,
    forKey key: String,
    completion: (Data?) -> Void
) {
    completion(cache.image(forKey: key))
}

@Suite("Дополнительный пример confirmation", .tags(.cache))
struct ConfirmationExamples {
    @Test("Completion вызывается один раз")
    func completionIsCalledOnce() async {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "avatar")

        await confirmation("Изображение передано в completion") { called in
            loadCachedImage(from: &cache, forKey: "avatar") { image in
                #expect(image == Data([1]))
                called()
            }
        }
    }
}
#endif
