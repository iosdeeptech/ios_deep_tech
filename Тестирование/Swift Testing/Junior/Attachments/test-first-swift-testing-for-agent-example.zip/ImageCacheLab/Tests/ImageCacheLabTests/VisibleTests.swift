import Foundation
import Testing
@testable import ImageCacheLab

extension Tag {
    @Tag static var cache: Self
}

@Suite("Видимый контракт кеша", .tags(.cache))
struct VisibleTests {
    @Test("Новый кеш пуст")
    func newCacheIsEmpty() {
        let cache = ImageCache(capacity: 2)
        #expect(cache.count == 0)
    }

    @Test("Возвращает сохранённые данные")
    func returnsInsertedData() throws {
        var cache = ImageCache(capacity: 2)
        let image = Data([1, 2, 3])
        cache.insert(image, forKey: "avatar")
        let result = cache.image(forKey: "avatar")
        let stored = try #require(result)
        #expect(stored == image)
    }

    @Test("Для неизвестного ключа возвращает nil")
    func missingKeyReturnsNil() {
        var cache = ImageCache(capacity: 2)
        #expect(cache.image(forKey: "missing") == nil)
    }

    @Test("Перезапись меняет данные, но не количество ключей")
    func replacementKeepsOneEntry() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "avatar")
        cache.insert(Data([2]), forKey: "avatar")
        #expect(cache.count == 1)
        #expect(cache.image(forKey: "avatar") == Data([2]))
    }

    @Test("Удаляет сохранённый ключ")
    func removesStoredKey() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "avatar")
        cache.remove(forKey: "avatar")
        #expect(cache.count == 0)
        #expect(cache.image(forKey: "avatar") == nil)
    }

    @Test("Удаление неизвестного ключа не затрагивает данные")
    func removingMissingKeyPreservesData() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "avatar")
        cache.remove(forKey: "missing")
        #expect(cache.count == 1)
        #expect(cache.image(forKey: "avatar") == Data([1]))
    }

    @Test("Не превышает вместимость", arguments: [0, 1, 2])
    func respectsCapacity(capacity: Int) {
        var cache = ImageCache(capacity: capacity)
        for key in ["a", "b", "c"] {
            cache.insert(Data([1]), forKey: key)
        }
        #expect(cache.count == capacity)
    }

    @Test("Без чтений вытесняет первую добавленную запись")
    func evictsOldestWithoutReads() {
        var cache = ImageCache(capacity: 2)
        cache.insert(Data([1]), forKey: "a")
        cache.insert(Data([2]), forKey: "b")
        cache.insert(Data([3]), forKey: "c")
        #expect(cache.image(forKey: "a") == nil)
        #expect(cache.image(forKey: "b") == Data([2]))
        #expect(cache.image(forKey: "c") == Data([3]))
    }
}
