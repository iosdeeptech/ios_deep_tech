#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
build_root="${ORDER_PRICE_BUILD_ROOT:-$project_root/.build}"
mkdir -p "$build_root/module-cache" "$build_root/swiftpm-cache"
export CLANG_MODULE_CACHE_PATH="$build_root/module-cache"
export SWIFTPM_MODULECACHE_OVERRIDE="$build_root/module-cache"
args=(--package-path "$project_root" --scratch-path "$build_root/package" --cache-path "$build_root/swiftpm-cache" --manifest-cache local)
if [[ "${ORDER_PRICE_DISABLE_NESTED_SANDBOX:-0}" == "1" ]]; then
    args+=(--disable-sandbox)
fi

xcrun swift build "${args[@]}"
xcrun swift test "${args[@]}"
python3 "$project_root/scripts/policy_check.py"
