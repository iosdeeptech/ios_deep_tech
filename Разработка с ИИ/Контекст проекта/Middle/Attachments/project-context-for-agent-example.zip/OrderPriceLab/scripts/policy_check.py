#!/usr/bin/env python3
"""A deliberately narrow text check, not a Swift parser or security boundary."""
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parent.parent
source_dir = root / "Sources" / "OrderPriceLab"
files = sorted(source_dir.rglob("*.swift"))
if not files:
    print("POLICY ERROR: no Swift source files found", file=sys.stderr)
    sys.exit(2)

forbidden = re.compile(r"\b(?:Double|Float)\b")
violations = []
for path in files:
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if forbidden.search(line):
            violations.append(f"{path.relative_to(root)}:{line_number}: {line.strip()}")

if violations:
    print("POLICY FAIL: OrderPriceLab must use integer kopecks; Double/Float tokens are forbidden.")
    print("\n".join(violations))
    sys.exit(1)

print("POLICY PASS: no Double/Float tokens in Sources/OrderPriceLab")
