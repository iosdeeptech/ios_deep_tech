// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "OrderPriceLab",
    platforms: [.macOS(.v15)],
    products: [.library(name: "OrderPriceLab", targets: ["OrderPriceLab"])],
    targets: [
        .target(name: "OrderPriceLab"),
        .testTarget(name: "OrderPriceLabTests", dependencies: ["OrderPriceLab"])
    ]
)
