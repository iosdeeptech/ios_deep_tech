import Testing
@testable import OrderPriceLab

struct OrderPriceTests {
    @Test(arguments: [
        ("0", Int64(0)), ("1", 100), ("1250", 125_000),
        ("9999999", 999_999_900), ("42", 4_200)
    ])
    func parsesWholeRubles(input: String, expected: Int64) {
        #expect(OrderPrice.parse(input)?.kopecks == expected)
    }

    @Test(arguments: [
        ("1,2", Int64(120)), ("1.2", 120), ("0.29", 29), ("0,01", 1),
        ("1250,50", 125_050), ("1250.50", 125_050), ("42.99", 4_299), ("9,00", 900)
    ])
    func parsesFraction(input: String, expected: Int64) {
        #expect(OrderPrice.parse(input)?.kopecks == expected)
    }

    @Test(arguments: [" 1250,50 ", "\t1250.50\t"])
    func trimsOnlyASCIISpacesAndTabs(input: String) {
        #expect(OrderPrice.parse(input)?.kopecks == 125_050)
    }

    @Test
    func acceptsMaximumAmount() throws {
        let price = try #require(OrderPrice.parse("9999999,99"))
        #expect(price.kopecks == 999_999_999)
    }

    @Test(arguments: [
        "", " ", "\t", "-1", "+1", ".5", "1.", "1,", "1.234", "1,234",
        "10000000", "1e3", "NaN", "inf", "1,2.3", "1..2", "1 250,50"
    ])
    func rejectsInvalidFormat(input: String) {
        #expect(OrderPrice.parse(input) == nil)
    }

    @Test(arguments: ["１２", "١٢", "1\u{00A0}250", "1٫25"])
    func rejectsNonASCIIFormats(input: String) {
        #expect(OrderPrice.parse(input) == nil)
    }

    @Test(arguments: ["1\n", "\n1", "1\r", "1\n2"])
    func rejectsLineBreaks(input: String) {
        #expect(OrderPrice.parse(input) == nil)
    }

    @Test(arguments: ["0001", "0001.00", "0000001,0"])
    func acceptsLeadingZeroes(input: String) {
        #expect(OrderPrice.parse(input)?.kopecks == 100)
    }
}
