import Foundation

public struct OrderPrice: Equatable, Sendable {
    public let kopecks: Int64

    public static func parse(_ input: String) -> OrderPrice? {
        let text = input
            .trimmingCharacters(in: CharacterSet(charactersIn: " \t"))
            .replacingOccurrences(of: ",", with: ".")
        let parts = text.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 1 || parts.count == 2 else { return nil }
        guard (1...7).contains(parts[0].utf8.count), isASCIIDigits(parts[0]) else {
            return nil
        }
        if parts.count == 2 {
            guard (1...2).contains(parts[1].utf8.count), isASCIIDigits(parts[1]) else {
                return nil
            }
        }

        let rubles = integerValue(parts[0])
        var fraction: Int64 = 0
        if parts.count == 2 {
            fraction = integerValue(parts[1])
            if parts[1].utf8.count == 1 { fraction *= 10 }
        }
        return OrderPrice(kopecks: rubles * 100 + fraction)
    }

    private static func isASCIIDigits(_ text: Substring) -> Bool {
        text.utf8.allSatisfy { (48...57).contains($0) }
    }

    private static func integerValue(_ text: Substring) -> Int64 {
        text.utf8.reduce(0) { $0 * 10 + Int64($1 - 48) }
    }
}
