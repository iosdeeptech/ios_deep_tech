import Foundation

public struct OrderPrice: Equatable, Sendable {
    public let kopecks: Int64

    public static func parse(_ input: String) -> OrderPrice? {
        let text = input
            .trimmingCharacters(in: CharacterSet(charactersIn: " \t"))
            .replacingOccurrences(of: ",", with: ".")
        let parts = text.split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 1 || parts.count == 2 else { return nil }
        guard (1...7).contains(parts[0].utf8.count), isASCIIDigits(parts[0]) else {
            return nil
        }
        if parts.count == 2 {
            guard (1...2).contains(parts[1].utf8.count), isASCIIDigits(parts[1]) else {
                return nil
            }
        }

        guard let rubles = Double(text) else { return nil }
        return OrderPrice(kopecks: Int64((rubles * 100).rounded()))
    }

    private static func isASCIIDigits(_ text: Substring) -> Bool {
        text.utf8.allSatisfy { (48...57).contains($0) }
    }
}
